PORTOFOLIO MATA KULIAH S2 STATISTIKA TERAPAN FMIPA UNPAD
Angkatan 2022-2025

Total dokumen mata kuliah: 66
Struktur folder: Angkatan -> Semester -> Portofolio per mata kuliah.
Lembar pengesahan berada pada halaman 2 dan telah memuat tanda tangan Kaprodi.
RPS tidak dilampirkan ulang; disimpan sebagai dokumen sumber terpisah.

ANGKATAN 2022
- Semester 1 (20221): D20B.101 - Teori Statistika | nilai valid 10/10
- Semester 1 (20221): D20B.102 - Analisis Data Multivariat | nilai valid 10/10
- Semester 1 (20221): D20B.103 - Analisis Regresi | nilai valid 10/10
- Semester 1 (20221): D20B.104 - Proses Stokastik | nilai valid 10/10
- Semester 1 (20221): D20B.105 - Komputasi Statistik | nilai valid 10/10
- Semester 1 (20221): D20O.106 - Konsep - konsep Dasar Statistika | nilai valid 6/6
- Semester 2 (20222): D200.207 - Analisis Data Deret Waktu | nilai valid 10/10
- Semester 2 (20222): D200.209 - Analisis Data Kategori | nilai valid 2/2
- Semester 2 (20222): D200.210 - Statistika Non Parametrik | nilai valid 35/51
- Semester 2 (20222): D20B.214 - Epidemiologi | nilai valid 9/9
- Semester 2 (20222): D20B.222 - Analisis Data Spasial | nilai valid 10/10
- Semester 2 (20222): D20B.301 - Seminar Usulan Riset (SUR) | nilai valid 5/10
- Semester 2 (20222): D20O.120 - Data Mining & Competitive Intelligence | nilai valid 10/10
- Semester 3 (20231): D20B.321 - Seminar Usulan Riset | nilai valid 4/5
- Semester 3 (20231): D20B.322 - Tesis | nilai valid 7/10
- Semester 4 (20232): D20B.321 - Seminar Usulan Riset | nilai valid 1/1
- Semester 4 (20232): D20B.322 - Tesis | nilai valid 3/3

ANGKATAN 2023
- Semester 1 (20231): D20B.101 - Statistik Inferential | nilai valid 21/22
- Semester 1 (20231): D20B.102 - Analisis Multivariat Tingkat Lanjut | nilai valid 21/22
- Semester 1 (20231): D20B.103 - Analisis Regresi Tingkat Lanjut | nilai valid 21/22
- Semester 1 (20231): D20B.104 - Proses Stokastik Tingkat Lanjut | nilai valid 22/22
- Semester 1 (20231): D20B.105 - Komputasi Statistik dan Optimasi | nilai valid 21/22
- Semester 1 (20231): D20B.107 - Analisis Deret Waktu Tingkat Lanjut | nilai valid 21/22
- Semester 2 (20232): D20B.206 - Model persamaan struktural | nilai valid 15/15
- Semester 2 (20232): D20B.209 - Analisis Data Kategori Tingkat Lanjut | nilai valid 8/8
- Semester 2 (20232): D20B.210 - Nonparamerics statistics dan flexible modeling | nilai valid 21/21
- Semester 2 (20232): D20B.222 - Analisis Data Spasial Tingkat Lanjut | nilai valid 11/11
- Semester 2 (20232): D20B.223 - Machine Learning | nilai valid 9/9
- Semester 2 (20232): D20B.225 - Text Analytics | nilai valid 7/7
- Semester 2 (20232): D20B.226 - Database | nilai valid 13/13
- Semester 2 (20232): D20B.321 - Seminar Usulan Riset | nilai valid 17/21
- Semester 2 (20232): D20O.120 - Data Mining dan Artificial Intelligence | nilai valid 21/21
- Semester 3 (20241): D20B.321 - Seminar Usulan Riset | nilai valid 6/18
- Semester 3 (20241): D20B.322 - Tesis | nilai valid 16/21
- Semester 4 (20242): D20B.321 - Seminar Usulan Riset | nilai valid 3/3
- Semester 4 (20242): D20B.322 - Tesis | nilai valid 5/5

ANGKATAN 2024
- Semester 1 (20241): D20B.101 - Statistik Inferential | nilai valid 15/15
- Semester 1 (20241): D20B.102 - Analisis Multivariat Tingkat Lanjut | nilai valid 15/15
- Semester 1 (20241): D20B.103 - Analisis Regresi Tingkat Lanjut | nilai valid 15/15
- Semester 1 (20241): D20B.104 - Proses Stokastik Tingkat Lanjut | nilai valid 15/15
- Semester 1 (20241): D20B.105 - Komputasi Statistik dan Optimasi | nilai valid 15/15
- Semester 1 (20241): D20B.107 - Analisis Deret Waktu Tingkat Lanjut | nilai valid 15/15
- Semester 2 (20242): D20B.210 - Nonparamerics statistics dan flexible modeling | nilai valid 14/14
- Semester 2 (20242): D20B.222 - Analisis Spasial Tingkat Lanjut | nilai valid 5/5
- Semester 2 (20242): D20B.223 - Machine Learning | nilai valid 13/13
- Semester 2 (20242): D20B.225 - Text Analytic | nilai valid 11/11
- Semester 2 (20242): D20B.226 - Database | nilai valid 13/13
- Semester 2 (20242): D20B.321 - Seminar Usulan Riset | nilai valid 3/14
- Semester 2 (20242): D20O.120 - Data Mining dan Artificial Intelligence | nilai valid 14/14
- Semester 3 (20251): D20B.321 - Seminar Usulan Riset | nilai valid 9/10
- Semester 3 (20251): D20B.322 - Tesis | nilai valid 12/13
- Semester 4 (20252): D20B.321 - Seminar Usulan Riset | nilai valid 1/1
- Semester 4 (20252): D20B.322 - Tesis | nilai valid 1/1

ANGKATAN 2025
- Semester 1 (20251): 140720-UND202511001 - Statistika Inferensial | nilai valid 14/14
- Semester 1 (20251): 140720-UND202511002 - Komputasi Statistik dan Optimasi | nilai valid 14/14
- Semester 1 (20251): 140720-UND202511003 - Analisis Multivariat Tingkat Lanjut | nilai valid 14/14
- Semester 1 (20251): 140720-UND202511004 - Analisis Regresi Tingkat Lanjut | nilai valid 14/14
- Semester 1 (20251): 140720-UND202511005 - Proses Stokastik Tingkat Lanjut | nilai valid 14/14
- Semester 1 (20251): 140720-UND202511006 - Analisis Deret Waktu Tingkat Lanjut | nilai valid 14/14
- Semester 2 (20252): 140720-UND202522001 - Statistika Nonparametrik dan Pemodelan Fleksibel | nilai valid 14/14
- Semester 2 (20252): 140720-UND202522002 - Penambangan Data dan Kecerdasan Buatan | nilai valid 14/14
- Semester 2 (20252): 140720-UND202522004 - Analisis Spasial | nilai valid 14/14
- Semester 2 (20252): 140720-UND202522014 - Epidemiologi | nilai valid 9/9
- Semester 2 (20252): 140720-UND202522015 - Pembelajaran Mesin | nilai valid 14/14
- Semester 2 (20252): 140720-UND202522016 - Analisis Image | nilai valid 13/13
- Semester 2 (20252): 140720-UND202522018 - Basis Data | nilai valid 6/6

REVISI LAYOUT LANDSCAPE
- Mulai blok tabel lebar, halaman diubah menjadi landscape.
- Rekap nilai mahasiswa memuat komponen asesmen yang digunakan dan dirender landscape agar tidak keluar margin.
- Tabel dengan 7 kolom atau lebih disetel ulang agar memanfaatkan lebar halaman landscape.


PENYESUAIAN TANGGAL PENGESAHAN BERDASARKAN KALENDER AKADEMIK UNPAD
Tanggal pengesahan ditetapkan pada tanggal akhir Masa Pengumuman Hasil Ujian Akhir Semester:
- 20221 / Gasal 2022/2023 : 09 Januari 2023
- 20222 / Genap 2022/2023 : 03 Juli 2023
- 20231 / Gasal 2023/2024 : 10 Januari 2024
- 20232 / Genap 2023/2024 : 15 Juli 2024
- 20241 / Gasal 2024/2025 : 06 Januari 2025
- 20242 / Genap 2024/2025 : 14 Juli 2025
- 20251 / Gasal 2025/2026 : 06 Januari 2026
- 20252 / Genap 2025/2026 : 11 Juli 2026
